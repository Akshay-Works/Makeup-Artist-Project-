/* ================================================
   ANVITA SHARMA BRIDAL STUDIO
   Complete JavaScript — All Interactions & Animations
   ================================================ */

'use strict';

/* ─── PRELOADER ──────────────────────────────── */
window.addEventListener('load', () => {
  const preloader = document.getElementById('preloader');
  if (!preloader) return;
  setTimeout(() => {
    preloader.classList.add('hidden');
    document.body.style.overflow = '';
    initScrollReveal();
    initStatCounters();
  }, 800);
});

document.body.style.overflow = 'hidden';

/* ─── NAVIGATION ─────────────────────────────── */
const header      = document.getElementById('site-header');
const navToggle   = document.getElementById('nav-toggle');
const navMenu     = document.getElementById('nav-menu');
const navLinks    = document.querySelectorAll('.nav-link');

// Scroll behaviour
let lastScroll = 0;
window.addEventListener('scroll', () => {
  const currentScroll = window.scrollY;
  if (currentScroll > 60) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
  lastScroll = currentScroll;
}, { passive: true });

// Mobile toggle
navToggle.addEventListener('click', () => {
  const isOpen = navMenu.classList.toggle('open');
  navToggle.classList.toggle('active', isOpen);
  navToggle.setAttribute('aria-expanded', String(isOpen));
  document.body.classList.toggle('menu-open', isOpen);
});

// Close on link click
navLinks.forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('open');
    navToggle.classList.remove('active');
    navToggle.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
  });
});

// Close on outside click
document.addEventListener('click', e => {
  if (navMenu.classList.contains('open') &&
      !navMenu.contains(e.target) &&
      !navToggle.contains(e.target)) {
    navMenu.classList.remove('open');
    navToggle.classList.remove('active');
    navToggle.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
  }
});

// Active nav link on scroll
const sections = document.querySelectorAll('section[id]');
const observerNavOptions = { rootMargin: '-40% 0px -55% 0px' };
const navObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navLinks.forEach(link => {
        link.classList.toggle(
          'active-link',
          link.getAttribute('href') === `#${entry.target.id}`
        );
      });
    }
  });
}, observerNavOptions);
sections.forEach(section => navObserver.observe(section));

/* ─── SCROLL REVEAL ANIMATIONS ───────────────── */
function initScrollReveal() {
  // Add reveal classes to elements
  const revealSelectors = [
    '.service-card',
    '.package-card',
    '.why-item',
    '.brand-item',
    '.faq-item',
    '.google-review-card',
    '.testimonial-card',
    '.process-step',
    '.about-grid',
    '.portfolio-item',
    '.stat-item',
    '.contact-form-wrap',
    '.contact-info-wrap',
    '.location-info',
    '.location-map',
    '.insta-item',
  ];

  revealSelectors.forEach(selector => {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.classList.add('reveal');
      el.style.transitionDelay = `${(i % 4) * 0.1}s`;
    });
  });

  const revealObserver = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: '0px 0px -60px 0px' }
  );

  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));
}

/* ─── STAT COUNTER ANIMATION ─────────────────── */
function initStatCounters() {
  const counters = document.querySelectorAll('.stat-number[data-target]');

  const counterObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseInt(el.dataset.target, 10);
      const suffix = el.querySelector('.stat-plus')?.textContent || '';
      const duration = 1800;
      const start = performance.now();

      const step = now => {
        const elapsed = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // ease-out-cubic
        const current = Math.floor(eased * target);
        el.firstChild.textContent = current.toLocaleString('en-IN');
        if (progress < 1) requestAnimationFrame(step);
        else el.firstChild.textContent = target.toLocaleString('en-IN');
      };
      requestAnimationFrame(step);
      counterObserver.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(counter => {
    counter.firstChild.textContent = '0';
    counterObserver.observe(counter);
  });
}

/* ─── PORTFOLIO FILTER ────────────────────────── */
const filterBtns = document.querySelectorAll('.filter-btn');
const portfolioItems = document.querySelectorAll('.portfolio-item');

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    // Update active button
    filterBtns.forEach(b => {
      b.classList.remove('active');
      b.setAttribute('aria-selected', 'false');
    });
    btn.classList.add('active');
    btn.setAttribute('aria-selected', 'true');

    const filter = btn.dataset.filter;

    portfolioItems.forEach(item => {
      const category = item.dataset.category;
      const show = filter === 'all' || category === filter;

      if (show) {
        item.style.display = '';
        // Trigger reflow for animation
        item.offsetHeight;
        item.style.opacity = '1';
        item.style.transform = 'scale(1)';
      } else {
        item.style.opacity = '0';
        item.style.transform = 'scale(0.9)';
        setTimeout(() => {
          if (item.style.opacity === '0') item.style.display = 'none';
        }, 300);
      }
    });
  });
});

// Set up portfolio items initial styles for animation
portfolioItems.forEach(item => {
  item.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
});

/* ─── LIGHTBOX ────────────────────────────────── */
const lightbox    = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');

function openLightbox(btn) {
  const img = btn.closest('.portfolio-item')?.querySelector('img');
  if (!img || !lightbox) return;
  lightboxImg.src = img.src.replace(/w=\d+/, 'w=1200');
  lightboxImg.alt = img.alt;
  lightbox.style.display = 'flex';
  document.body.style.overflow = 'hidden';
  lightbox.focus();
}

function closeLightbox() {
  if (!lightbox) return;
  lightbox.style.display = 'none';
  document.body.style.overflow = '';
}

// Close on overlay click
lightbox?.addEventListener('click', e => {
  if (e.target === lightbox) closeLightbox();
});

// Close on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeLightbox();
    closeNavIfOpen();
  }
});

function closeNavIfOpen() {
  if (navMenu.classList.contains('open')) {
    navMenu.classList.remove('open');
    navToggle.classList.remove('active');
    navToggle.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
  }
}

// Expose to HTML onclick
window.openLightbox  = openLightbox;
window.closeLightbox = closeLightbox;

/* ─── BEFORE & AFTER SLIDER ──────────────────── */
(function initBASlider() {
  const slider   = document.getElementById('baSlider');
  const handle   = document.getElementById('baHandle');
  const afterDiv = slider?.querySelector('.ba-after');
  if (!slider || !handle || !afterDiv) return;

  let isDragging = false;

  function setPosition(clientX) {
    const rect = slider.getBoundingClientRect();
    let x = clientX - rect.left;
    x = Math.max(0, Math.min(x, rect.width));
    const pct = (x / rect.width) * 100;
    afterDiv.style.width = pct + '%';
    handle.style.left = pct + '%';
    handle.setAttribute('aria-valuenow', Math.round(pct));
  }

  // Mouse events
  handle.addEventListener('mousedown', e => {
    isDragging = true;
    e.preventDefault();
  });

  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    setPosition(e.clientX);
  });

  document.addEventListener('mouseup', () => { isDragging = false; });

  // Touch events
  handle.addEventListener('touchstart', e => {
    isDragging = true;
    e.preventDefault();
  }, { passive: false });

  document.addEventListener('touchmove', e => {
    if (!isDragging) return;
    setPosition(e.touches[0].clientX);
  }, { passive: true });

  document.addEventListener('touchend', () => { isDragging = false; });

  // Keyboard control
  handle.addEventListener('keydown', e => {
    const rect = slider.getBoundingClientRect();
    const currentLeft = parseFloat(handle.style.left) || 50;
    let newLeft = currentLeft;
    if (e.key === 'ArrowLeft')  newLeft = Math.max(0, currentLeft - 2);
    if (e.key === 'ArrowRight') newLeft = Math.min(100, currentLeft + 2);
    if (newLeft !== currentLeft) {
      afterDiv.style.width = newLeft + '%';
      handle.style.left = newLeft + '%';
      handle.setAttribute('aria-valuenow', Math.round(newLeft));
    }
  });

  // Also allow clicking on the slider itself
  slider.addEventListener('click', e => {
    if (e.target === handle || handle.contains(e.target)) return;
    setPosition(e.clientX);
  });
})();

/* ─── TESTIMONIALS CAROUSEL ──────────────────── */
(function initCarousel() {
  const track     = document.getElementById('testimonialsTrack');
  const dotsWrap  = document.getElementById('carouselDots');
  if (!track || !dotsWrap) return;

  const cards     = track.querySelectorAll('.testimonial-card');
  const total     = cards.length;
  let current     = 0;
  let autoTimer   = null;
  let perView     = getPerView();

  function getPerView() {
    if (window.innerWidth <= 768) return 1;
    if (window.innerWidth <= 960) return 2;
    return 3;
  }

  const maxIndex = () => Math.max(0, total - perView);

  // Build dots
  function buildDots() {
    dotsWrap.innerHTML = '';
    const dotCount = maxIndex() + 1;
    for (let i = 0; i < dotCount; i++) {
      const dot = document.createElement('button');
      dot.className = 'dot' + (i === current ? ' active' : '');
      dot.setAttribute('role', 'tab');
      dot.setAttribute('aria-label', `Testimonial ${i + 1}`);
      dot.addEventListener('click', () => goTo(i));
      dotsWrap.appendChild(dot);
    }
  }

  function updateDots() {
    dotsWrap.querySelectorAll('.dot').forEach((d, i) => {
      d.classList.toggle('active', i === current);
    });
  }

  function goTo(index) {
    current = Math.max(0, Math.min(index, maxIndex()));
    const cardWidth = cards[0].offsetWidth + 24; // gap = 1.5rem = 24px
    track.style.transform = `translateX(-${current * cardWidth}px)`;
    updateDots();
  }

  function goNext() { goTo(current < maxIndex() ? current + 1 : 0); }
  function goPrev() { goTo(current > 0 ? current - 1 : maxIndex()); }

  function startAuto() {
    stopAuto();
    autoTimer = setInterval(goNext, 5000);
  }

  function stopAuto() {
    if (autoTimer) clearInterval(autoTimer);
  }

  // Pause on hover
  track.addEventListener('mouseenter', stopAuto);
  track.addEventListener('mouseleave', startAuto);

  // Touch swipe
  let touchStartX = 0;
  track.addEventListener('touchstart', e => {
    touchStartX = e.touches[0].clientX;
    stopAuto();
  }, { passive: true });

  track.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) diff > 0 ? goNext() : goPrev();
    startAuto();
  }, { passive: true });

  // Expose to global
  window.moveCarousel = (dir) => {
    stopAuto();
    dir > 0 ? goNext() : goPrev();
    startAuto();
  };

  // Resize
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const newPer = getPerView();
      if (newPer !== perView) {
        perView = newPer;
        current = 0;
        buildDots();
        goTo(0);
      }
    }, 200);
  });

  buildDots();
  goTo(0);
  startAuto();
})();

/* ─── FAQ ACCORDION ──────────────────────────── */
window.toggleFaq = function(btn) {
  const answer    = btn.nextElementSibling;
  const isOpen    = btn.getAttribute('aria-expanded') === 'true';
  const allBtns   = document.querySelectorAll('.faq-question');

  // Close all
  allBtns.forEach(b => {
    b.setAttribute('aria-expanded', 'false');
    b.nextElementSibling?.classList.remove('open');
  });

  // Open clicked if it was closed
  if (!isOpen) {
    btn.setAttribute('aria-expanded', 'true');
    answer?.classList.add('open');
  }
};

/* ─── CONTACT FORM ────────────────────────────── */
(function initContactForm() {
  const form    = document.getElementById('contactForm');
  const success = document.getElementById('formSuccess');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!validateForm(form)) return;

    // Build WhatsApp message from form
    const name    = form.elements['name']?.value.trim();
    const phone   = form.elements['phone']?.value.trim();
    const date    = form.elements['date']?.value;
    const service = form.elements['service']?.value;
    const message = form.elements['message']?.value.trim();

    const waMsg = encodeURIComponent(
      `Hi Anvita! 🌸\n\nI am interested in your bridal services.\n\n` +
      `*Name:* ${name}\n` +
      `*Phone:* ${phone}\n` +
      `*Wedding Date:* ${date || 'TBD'}\n` +
      `*Service Required:* ${service}\n` +
      `*Message:* ${message || 'None'}\n\n` +
      `Looking forward to hearing from you!`
    );

    // Show success message
    success.style.display = 'flex';
    form.reset();

    // Redirect to WhatsApp after short delay
    setTimeout(() => {
      window.open(`https://wa.me/919876543210?text=${waMsg}`, '_blank', 'noopener,noreferrer');
    }, 1000);

    // Hide success after 6s
    setTimeout(() => { success.style.display = 'none'; }, 6000);
  });

  function validateForm(form) {
    let valid = true;
    const required = form.querySelectorAll('[required]');
    required.forEach(field => {
      field.style.borderColor = '';
      if (!field.value.trim()) {
        field.style.borderColor = '#ef4444';
        field.focus();
        valid = false;
      }
    });
    return valid;
  }

  // Real-time validation feedback
  form.querySelectorAll('[required]').forEach(field => {
    field.addEventListener('blur', () => {
      field.style.borderColor = field.value.trim() ? '' : '#ef4444';
    });
    field.addEventListener('input', () => {
      if (field.value.trim()) field.style.borderColor = '';
    });
  });
})();

/* ─── FLOATING BOOK NOW (MOBILE) ─────────────── */
(function initFloatingCTA() {
  const bar     = document.getElementById('floatingBookNow');
  const hero    = document.getElementById('hero');
  const footer  = document.querySelector('.site-footer');
  if (!bar || !hero) return;

  const isMobile = () => window.innerWidth <= 768;

  function updateVisibility() {
    if (!isMobile()) { bar.style.display = 'none'; return; }
    const heroBottom   = hero.getBoundingClientRect().bottom;
    const footerTop    = footer?.getBoundingClientRect().top ?? Infinity;
    const windowHeight = window.innerHeight;

    if (heroBottom < 0 && footerTop > windowHeight) {
      bar.style.display = 'block';
    } else {
      bar.style.display = 'none';
    }
  }

  window.addEventListener('scroll', updateVisibility, { passive: true });
  window.addEventListener('resize', updateVisibility, { passive: true });
  updateVisibility();
})();

/* ─── SMOOTH SCROLL FOR ANCHOR LINKS ─────────── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', e => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const headerHeight = header?.offsetHeight ?? 80;
    const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 16;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* ─── LAZY IMAGE LOADING ENHANCEMENT ─────────── */
(function initLazyLoad() {
  if ('loading' in HTMLImageElement.prototype) return; // native support
  const images = document.querySelectorAll('img[loading="lazy"]');
  const lazyObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src || img.src;
        lazyObserver.unobserve(img);
      }
    });
  }, { rootMargin: '200px' });
  images.forEach(img => lazyObserver.observe(img));
})();

/* ─── WHATSAPP PULSE ANIMATION ───────────────── */
(function initWAPulse() {
  const wa = document.getElementById('stickyWA');
  if (!wa) return;
  // Add a subtle bounce every 8 seconds
  setInterval(() => {
    wa.style.animation = 'none';
    wa.offsetHeight; // trigger reflow
    wa.style.animation = 'waBounce 0.6s ease-in-out';
  }, 8000);
})();

// Inject bounce keyframe dynamically
const bounceStyle = document.createElement('style');
bounceStyle.textContent = `
  @keyframes waBounce {
    0%, 100% { transform: scale(1); }
    30% { transform: scale(1.15) rotate(-5deg); }
    60% { transform: scale(1.1) rotate(5deg); }
    80% { transform: scale(1.05); }
  }
`;
document.head.appendChild(bounceStyle);

/* ─── HEADER NAV HIGHLIGHT ACTIVE SECTION ────── */
(function initActiveNav() {
  const sectionMap = {
    'hero': null,
    'about': document.querySelector('.nav-link[href="#about"]'),
    'services': document.querySelector('.nav-link[href="#services"]'),
    'portfolio': document.querySelector('.nav-link[href="#portfolio"]'),
    'packages': document.querySelector('.nav-link[href="#packages"]'),
    'testimonials': document.querySelector('.nav-link[href="#testimonials"]'),
    'contact': document.querySelector('.nav-link[href="#contact"]'),
  };

  const highlightObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      Object.values(sectionMap).forEach(link => link?.classList.remove('nav-active'));
      sectionMap[entry.target.id]?.classList.add('nav-active');
    });
  }, { rootMargin: '-30% 0px -65% 0px' });

  Object.keys(sectionMap).forEach(id => {
    const el = document.getElementById(id);
    if (el) highlightObserver.observe(el);
  });

  // CSS for active nav link
  const navActiveStyle = document.createElement('style');
  navActiveStyle.textContent = `
    .nav-active { color: var(--rose-gold) !important; }
    .nav-active::after { transform: scaleX(1) !important; }
  `;
  document.head.appendChild(navActiveStyle);
})();

/* ─── IMAGE ERROR FALLBACK ────────────────────── */
document.querySelectorAll('img').forEach(img => {
  img.addEventListener('error', function () {
    this.style.background = 'linear-gradient(135deg, #F2D4CF, #FAF0EE)';
    this.removeAttribute('src');
  });
});

/* ─── PERFORMANCE: DEBOUNCE UTILITY ──────────── */
function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

/* ─── BACK TO TOP ON LOGO CLICK ──────────────── */
document.querySelectorAll('a[href="#hero"]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});

/* ─── SERVICE CARD HOVER MICRO-INTERACTION ────── */
document.querySelectorAll('.service-card').forEach(card => {
  card.addEventListener('mouseenter', function () {
    this.style.willChange = 'transform';
  });
  card.addEventListener('mouseleave', function () {
    this.style.willChange = '';
  });
});

/* ─── PACKAGE CARD HIGHLIGHT ─────────────────── */
document.querySelectorAll('.package-card').forEach(card => {
  card.addEventListener('mouseenter', function () {
    document.querySelectorAll('.package-card').forEach(c => {
      if (c !== this) c.style.opacity = '0.75';
    });
  });
  card.addEventListener('mouseleave', function () {
    document.querySelectorAll('.package-card').forEach(c => {
      c.style.opacity = '';
    });
  });
});

/* ─── GOOGLE MAP INTERACTION FIX ─────────────── */
(function fixMapScroll() {
  const mapContainer = document.querySelector('.location-map');
  if (!mapContainer) return;
  mapContainer.addEventListener('click', () => {
    const iframe = mapContainer.querySelector('iframe');
    if (iframe) iframe.style.pointerEvents = 'all';
  });
  mapContainer.addEventListener('mouseleave', () => {
    const iframe = mapContainer.querySelector('iframe');
    if (iframe) iframe.style.pointerEvents = 'none';
  });
  // Initially disable to allow page scroll
  const iframe = mapContainer.querySelector('iframe');
  if (iframe) iframe.style.pointerEvents = 'none';
})();

/* ─── HEADER LOGO ANIMATION ON SCROLL ────────── */
(function initLogoShrink() {
  const logoScript = document.querySelector('.nav-logo .logo-script');
  if (!logoScript) return;

  window.addEventListener('scroll', debounce(() => {
    if (window.scrollY > 100) {
      logoScript.style.fontSize = '1.5rem';
    } else {
      logoScript.style.fontSize = '';
    }
    logoScript.style.transition = 'font-size 0.3s ease';
  }, 10), { passive: true });
})();

/* ─── HERO PARALLAX (subtle) ─────────────────── */
(function initHeroParallax() {
  const heroBg = document.querySelector('.hero-bg-img');
  if (!heroBg || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    if (scrolled < window.innerHeight) {
      heroBg.style.transform = `scale(1) translateY(${scrolled * 0.25}px)`;
    }
  }, { passive: true });
})();

/* ─── BRAND LOGO HOVER EFFECT ────────────────── */
document.querySelectorAll('.brand-logo-box').forEach(box => {
  box.addEventListener('mouseenter', function () {
    this.style.background = 'linear-gradient(135deg, #FAF0EE 0%, #FBF7F4 100%)';
  });
  box.addEventListener('mouseleave', function () {
    this.style.background = '';
  });
});

/* ─── PROCESS STEP ANIMATION ─────────────────── */
(function initProcessAnimation() {
  const steps = document.querySelectorAll('.process-step');
  if (!steps.length) return;

  const processObserver = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, i * 150);
        processObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  steps.forEach((step, i) => {
    step.style.opacity = '0';
    step.style.transform = 'translateY(30px)';
    step.style.transition = `opacity 0.6s ease ${i * 0.1}s, transform 0.6s ease ${i * 0.1}s`;
    processObserver.observe(step);
  });
})();

/* ─── COOKIE CONSENT (Minimal) ───────────────── */
(function initCookieNotice() {
  if (localStorage.getItem('cookieAccepted')) return;

  const notice = document.createElement('div');
  notice.id = 'cookieNotice';
  notice.setAttribute('role', 'alertdialog');
  notice.setAttribute('aria-label', 'Cookie consent');
  notice.innerHTML = `
    <p>We use cookies to enhance your experience. By continuing, you agree to our use of cookies.</p>
    <button id="acceptCookies">Accept</button>
  `;
  notice.style.cssText = `
    position: fixed; bottom: 1.5rem; left: 1.5rem; right: 7rem;
    background: #1A1008; color: rgba(255,255,255,0.85);
    padding: 1rem 1.25rem; border-radius: 12px;
    font-size: .8125rem; line-height: 1.6;
    display: flex; align-items: center; justify-content: space-between; gap: 1rem;
    z-index: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.25);
    flex-wrap: wrap; max-width: 600px;
    animation: fadeUp 0.4s ease both;
  `;

  document.body.appendChild(notice);

  const acceptBtn = document.getElementById('acceptCookies');
  acceptBtn.style.cssText = `
    padding: .5rem 1.25rem; background: #C9956C; color: white;
    border: none; border-radius: 100px; font-size: .8rem; cursor: pointer;
    white-space: nowrap; font-weight: 500; flex-shrink: 0;
  `;

  acceptBtn.addEventListener('click', () => {
    localStorage.setItem('cookieAccepted', '1');
    notice.style.animation = 'none';
    notice.style.opacity = '0';
    notice.style.transform = 'translateY(20px)';
    notice.style.transition = 'opacity 0.3s, transform 0.3s';
    setTimeout(() => notice.remove(), 350);
  });
})();

/* ─── SOCIAL PROOF TOAST NOTIFICATIONS ───────── */
(function initSocialProofToasts() {
  const toasts = [
    { name: 'Priya M.', action: 'just booked Bridal Makeup', time: '2 minutes ago' },
    { name: 'Sneha K.', action: 'left a 5-star review', time: '15 minutes ago' },
    { name: 'Ananya J.', action: 'booked the Luxury Package', time: '32 minutes ago' },
    { name: 'Riya D.', action: 'enquired about Bridal Mehendi', time: '1 hour ago' },
    { name: 'Kavita P.', action: 'booked for December 2025', time: '2 hours ago' },
  ];

  let toastIndex = 0;

  function showToast() {
    const data = toasts[toastIndex % toasts.length];
    toastIndex++;

    const toast = document.createElement('div');
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    toast.innerHTML = `
      <div style="display:flex;align-items:center;gap:.75rem;">
        <div style="
          width:36px;height:36px;border-radius:50%;flex-shrink:0;
          background:linear-gradient(135deg,#F2D4CF,#C9956C);
          display:flex;align-items:center;justify-content:center;
          color:white;font-weight:600;font-size:.875rem;font-family:serif;
        ">${data.name.charAt(0)}</div>
        <div>
          <strong style="display:block;font-size:.8125rem;color:#1A1008;">${data.name}</strong>
          <span style="font-size:.75rem;color:#7A5C4E;">${data.action}</span>
        </div>
      </div>
      <div style="font-size:.6875rem;color:#B89080;margin-top:.375rem;">${data.time}</div>
    `;

    toast.style.cssText = `
      position: fixed; bottom: 7rem; left: 1.5rem;
      background: white; border: 1px solid #EEDDD6;
      border-radius: 12px; padding: .875rem 1rem;
      box-shadow: 0 8px 32px rgba(60,30,15,0.15);
      z-index: 450; max-width: 260px;
      transform: translateX(-120%);
      transition: transform 0.4s cubic-bezier(0.22,1,0.36,1);
      font-family: 'Jost', sans-serif;
    `;

    document.body.appendChild(toast);

    // Slide in
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        toast.style.transform = 'translateX(0)';
      });
    });

    // Slide out after 4s
    setTimeout(() => {
      toast.style.transform = 'translateX(-120%)';
      setTimeout(() => toast.remove(), 450);
    }, 4000);
  }

  // Start after 6 seconds, then every 12 seconds
  setTimeout(() => {
    showToast();
    setInterval(showToast, 12000);
  }, 6000);
})();

/* ─── AVAILABILITY URGENCY BANNER ────────────── */
(function initUrgencyBanner() {
  // Check if already dismissed this session
  if (sessionStorage.getItem('urgencyDismissed')) return;

  const banner = document.createElement('div');
  banner.id = 'urgencyBanner';
  banner.setAttribute('role', 'banner');
  banner.innerHTML = `
    <span>
      🌸 Only <strong>3 dates left</strong> for the 2025–26 wedding season — 
      <a href="https://wa.me/919876543210?text=Hi!%20I%20want%20to%20check%20availability%20for%202025-26." 
         target="_blank" rel="noopener noreferrer" style="color:var(--gold-light);text-decoration:underline;">
        Check Your Date Now
      </a>
    </span>
    <button id="closeBanner" aria-label="Close announcement">&times;</button>
  `;
  banner.style.cssText = `
    background: linear-gradient(135deg, #1A1008 0%, #3D2B1F 100%);
    color: rgba(255,255,255,0.9); text-align: center;
    padding: .625rem 3rem .625rem 1rem;
    font-size: .8125rem; font-family: 'Jost',sans-serif;
    position: relative; z-index: 1001;
    display: flex; align-items: center; justify-content: center;
    gap: 1rem; line-height: 1.5;
  `;

  document.body.insertBefore(banner, document.body.firstChild);

  // Adjust header top
  if (header) header.style.top = banner.offsetHeight + 'px';

  const closeBanner = document.getElementById('closeBanner');
  closeBanner.style.cssText = `
    position: absolute; right: 1rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; color: rgba(255,255,255,0.6);
    font-size: 1.25rem; cursor: pointer; padding: .25rem;
    transition: color 0.2s;
  `;
  closeBanner.addEventListener('mouseenter', () => closeBanner.style.color = 'white');
  closeBanner.addEventListener('mouseleave', () => closeBanner.style.color = 'rgba(255,255,255,0.6)');

  closeBanner.addEventListener('click', () => {
    banner.style.maxHeight = banner.offsetHeight + 'px';
    banner.style.overflow = 'hidden';
    banner.style.transition = 'max-height 0.3s ease, padding 0.3s ease';
    requestAnimationFrame(() => {
      banner.style.maxHeight = '0';
      banner.style.padding = '0';
    });
    setTimeout(() => {
      banner.remove();
      if (header) header.style.top = '';
    }, 350);
    sessionStorage.setItem('urgencyDismissed', '1');
  });
})();

/* ─── CONSOLE BRAND MESSAGE ───────────────────── */
console.log(
  '%c✨ Anvita Sharma Bridal Studio %c\nDesigned for Pune\'s most beautiful brides.\n',
  'color: #C9956C; font-size: 1.2rem; font-weight: bold; font-family: Georgia, serif;',
  'color: #7A5C4E; font-size: 0.875rem; font-family: sans-serif;'
);

/* ─── DOMContentLoaded INIT ──────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  // Set initial BA slider position
  const baAfter  = document.querySelector('.ba-after');
  const baHandle = document.getElementById('baHandle');
  if (baAfter && baHandle) {
    baAfter.style.width  = '50%';
    baHandle.style.left  = '50%';
  }

  // Ensure portfolio items visible on load
  portfolioItems.forEach(item => {
    item.style.opacity = '1';
    item.style.transform = 'scale(1)';
  });

  // Mark first section as visible immediately
  document.querySelector('#hero')?.classList.add('visible');
});
